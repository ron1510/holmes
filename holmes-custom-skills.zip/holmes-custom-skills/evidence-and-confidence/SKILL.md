---
name: evidence-and-confidence
description: Apply evidence sufficiency, uncertainty, confidence, and anti-hallucination rules to any Holmes investigation. Use whenever deciding whether a root cause can be claimed from Prometheus metrics and Grafana dashboards.
---

# Evidence and Confidence

## Goal

Prevent unsupported RCA conclusions. Require Holmes to distinguish observed facts, hypotheses, and unknowns, and to explicitly request missing data when available observability cannot answer the question.

## Core Rules

1. Never claim a root cause without supporting observable evidence.
2. Never invent metrics, values, dashboards, labels, incidents, dependencies, or events.
3. Never treat missing data as normal or healthy data.
4. Never present correlation as causation.
5. Never choose one hypothesis merely because it sounds more common or plausible.
6. If multiple hypotheses fit the observed data and the available metrics cannot distinguish them, return `INSUFFICIENT_EVIDENCE`.
7. If the root cause requires information outside the approved toolsets, explicitly state what data is needed.
8. A precise "I do not know yet" is better than an unsupported RCA.

## Evidence Classification

Separate findings into:

### Observed
Facts directly supported by queried metrics or dashboard data.

### Inferred
Reasonable conclusions derived from observed facts. State the reasoning.

### Unknown
Information that is required but not available in the current observability data.

Do not move an item from `Inferred` to `Observed`.

## RCA Decision Gate

Before producing a root cause, answer:

1. What exact symptom is proven by the data?
2. What candidate causes are consistent with it?
3. What evidence supports the leading candidate?
4. What evidence contradicts the leading candidate?
5. What alternative candidates remain plausible?
6. Do the available metrics distinguish the leading candidate from those alternatives?
7. Is the timing consistent with causality?
8. Is there enough evidence to explain both the symptom and the affected scope?

If the answer to question 6 or 8 is no, do not claim RCA.

## Confidence Levels

Use:

- `HIGH`: Evidence strongly supports one explanation and important alternatives are contradicted or ruled out by available data.
- `MEDIUM`: Evidence favors one explanation, but meaningful uncertainty remains.
- `LOW`: Evidence is weak or multiple explanations remain plausible. Do not present this as a confirmed RCA.
- `INSUFFICIENT_EVIDENCE`: Available observability cannot distinguish the plausible explanations or required data is missing.

Confidence is not a probability.

## Required Output

When evidence is sufficient:

```text
Status: RCA_SUPPORTED
Confidence: HIGH | MEDIUM

Observed:
- ...

Root-cause hypothesis:
- ...

Supporting evidence:
- ...

Contradicting evidence:
- ...

Alternative explanations considered:
- ...

Recommended next action:
- ...
```

When evidence is insufficient:

```text
Status: INSUFFICIENT_EVIDENCE
Confidence: LOW

Observed:
- ...

What can be concluded:
- ...

Plausible explanations:
- ...

Missing data:
- <exact metric, dashboard signal, or observability category>
- ...

Why it is needed:
- <explain which hypotheses this data would distinguish>

Next investigation step:
- ...
```

## Missing Data Requirements

Be specific. Prefer:

- `disk queue depth for mongo-prod during 14:20-14:40`

over:

- `more disk metrics`

Prefer:

- `connection utilization against configured max`

over:

- `connection information`

If the required information cannot be obtained through Prometheus or Grafana, say so explicitly:

```text
The current observability-only scope cannot establish this root cause.
To continue, the following additional telemetry would need to be exported into Prometheus or exposed through an approved dashboard:
- ...
```

Do not request direct access to the database unless the user explicitly changes the investigation policy.

## Synthesize Findings

The final answer must make it obvious which statements are observed, inferred, and unknown. If evidence is incomplete, the missing-data request is part of the investigation result, not a failure.
