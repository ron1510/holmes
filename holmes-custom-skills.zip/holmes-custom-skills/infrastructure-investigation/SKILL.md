---
name: infrastructure-investigation
description: Investigate infrastructure incidents using only approved observability data from Prometheus metrics and Grafana dashboards. Use for broad or unclear infrastructure issues where the affected component or failure domain is not yet known.
---

# Infrastructure Investigation

## Goal

Identify the affected system, establish the incident timeline, locate the most relevant observability signals, and narrow the investigation to the most likely failure domain.

## Scope and Safety

- Use only approved Prometheus metrics and Grafana dashboards.
- Do not query databases, infrastructure APIs, cloud APIs, Kubernetes APIs, logs, traces, shell commands, or the Internet unless they are explicitly enabled for a future phase.
- Do not assume missing data is healthy data.
- Do not claim a root cause based only on correlation.
- If the available observability data is insufficient, stop and report exactly what additional data is required.

## Workflow

1. **Identify the affected scope**
   - Determine the affected service, database, cluster, instance, environment, and time window when possible.
   - If any of these are unknown, use dashboards and metric labels to narrow the scope.

2. **Locate the relevant dashboard**
   - Find the dashboard or dashboard section representing the affected system.
   - Prefer organization-approved dashboards over ad-hoc queries when both provide the same signal.
   - Record the important panels and the PromQL queries they represent.

3. **Establish a baseline**
   - Compare the incident window with a nearby healthy period.
   - When useful, compare against the same system before the incident or an equivalent healthy instance.
   - Avoid fixed thresholds unless the organization explicitly defines them.

4. **Check the major signal groups**
   - Availability and errors
   - Latency
   - Throughput
   - Resource saturation
   - Connection or queue pressure
   - Storage or replication indicators when exposed

5. **Build a timeline**
   - Identify which metrics changed first.
   - Separate primary changes from downstream symptoms.
   - Correlate signals by timestamp and affected instance.

6. **Select the next investigation path**
   - Database-related degradation -> use the database investigation workflow.
   - Latency/performance degradation -> use the performance investigation workflow.
   - Availability/errors -> use the availability investigation workflow.
   - Resource pressure -> use the resource saturation investigation workflow.

7. **Apply evidence rules**
   - Before concluding, apply the evidence-and-confidence rules.
   - If the data does not distinguish between plausible explanations, return `INSUFFICIENT_EVIDENCE`.

## Synthesize Findings

Report:

- Affected system and time window
- Observed symptoms
- Most relevant abnormal metrics
- Timeline of changes
- Leading hypothesis or hypotheses
- Evidence supporting each hypothesis
- Evidence contradicting each hypothesis
- Confidence level
- Missing evidence

## Recommended Remediation Steps

Only recommend remediation when it follows directly from the observed evidence. If root cause is not established, recommend the next observability data required rather than a speculative fix.
