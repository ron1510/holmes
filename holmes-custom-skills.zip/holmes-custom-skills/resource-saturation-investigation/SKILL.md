---
name: resource-saturation-investigation
description: Investigate CPU, memory, disk, connection, queue, I/O, or other resource saturation using only Prometheus metrics and Grafana dashboards, and determine whether saturation is a likely cause or a downstream symptom.
---

# Resource Saturation Investigation

## Goal

Determine whether observed resource pressure is causal, contributory, or merely correlated with an incident.

## Scope and Safety

- Use only Prometheus metrics and Grafana dashboards.
- Do not assume high utilization means root cause.
- Prefer saturation and wait indicators over utilization alone when available.
- Compare affected and healthy instances.

## Workflow

1. **Identify the saturated resource**
   - CPU
   - Memory
   - Disk / I/O
   - Connections
   - Queue
   - Network or other exposed capacity resource

2. **Quantify severity**
   - Current value
   - Limit/capacity where available
   - Utilization percentage
   - Duration
   - Frequency

3. **Check saturation-specific indicators**
   - CPU throttling or run queue
   - Memory pressure, reclaim, swap, OOM indicators
   - Disk latency, queue depth, IOPS saturation
   - Connection utilization, waits, failures
   - Queue depth and processing rate

4. **Compare timing**
   - Did saturation begin before the incident symptom?
   - Did the user-visible symptom begin first?
   - Did both occur simultaneously?

5. **Compare peers**
   - Healthy vs affected instances
   - Same workload with different resource behavior
   - Same resource pressure without user-visible impact

6. **Check load**
   - Determine whether throughput or traffic increased.
   - Separate normal load-driven utilization from abnormal saturation.

7. **Classify the resource signal**
   - `LIKELY_CAUSAL`
   - `CONTRIBUTING_FACTOR`
   - `LIKELY_SYMPTOM`
   - `CORRELATED_ONLY`
   - `INSUFFICIENT_EVIDENCE`

8. **Apply evidence rules**
   - Use evidence-and-confidence rules before claiming causality.

## Synthesize Findings

Report:

- Saturated resource
- Severity
- Saturation/wait indicators
- Timing relative to incident
- Peer comparison
- Classification
- Confidence
- Missing evidence

## Recommended Remediation Steps

Recommend scaling or tuning only when saturation is supported as causal or contributory. If utilization is high but causal evidence is weak, ask for the specific metrics needed to distinguish cause from symptom.
