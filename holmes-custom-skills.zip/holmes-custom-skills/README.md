# Holmes Custom Skills – Observability-Only POC

This package is designed for a HolmesGPT deployment where investigations are restricted to:

- Prometheus metrics
- Grafana dashboards

No direct database access is assumed.

## Skills

- `infrastructure-investigation`
- `database-investigation`
- `performance-investigation`
- `availability-investigation`
- `resource-saturation-investigation`
- `evidence-and-confidence`

## Load from CLI config

Add to `~/.holmes/config.yaml`:

```yaml
custom_skill_paths:
  - /path/to/holmes-custom-skills
```

For an air-gapped deployment, mount this directory locally or through your approved deployment mechanism.

The `evidence-and-confidence` skill is intentionally strict: when the metrics cannot distinguish between plausible causes, Holmes should return `INSUFFICIENT_EVIDENCE` and list the exact missing telemetry required.
