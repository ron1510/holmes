---
name: availability-investigation
description: Investigate downtime, unavailability, connection failures, timeouts, or error spikes using only Prometheus metrics and Grafana dashboards.
---

# Availability Investigation

## Goal

Determine the scope and observable cause of an availability incident while avoiding unsupported assumptions when the observability layer cannot expose the underlying failure.

## Scope and Safety

- Use only Prometheus metrics and Grafana dashboards.
- Do not access databases, hosts, Kubernetes, cloud APIs, logs, traces, shell, or the Internet.
- Distinguish complete outage, partial degradation, and client-specific symptoms.
- Do not equate an error spike with a root cause.

## Workflow

1. **Determine impact**
   - Full outage vs partial outage
   - Affected environment
   - Affected cluster/instance/service
   - Start time and duration

2. **Check availability and error signals**
   - Health/availability metrics
   - Error rate
   - Timeout rate
   - Failed connection metrics
   - Success rate

3. **Check traffic**
   - Request/operation rate
   - Determine whether traffic disappeared, shifted, or surged

4. **Check saturation indicators**
   - CPU
   - Memory
   - Connections
   - Queues
   - Disk/storage
   - Any system-specific capacity metric

5. **Check cluster/replication indicators**
   - Replica availability
   - Replication lag
   - Leader/failover indicators
   - Instance imbalance when exposed

6. **Build an incident timeline**
   - Identify the earliest abnormal metric.
   - Determine which symptoms followed.
   - Compare affected and healthy instances when possible.

7. **Assess evidence sufficiency**
   - Apply evidence-and-confidence rules.
   - If metrics confirm an outage but not its underlying mechanism, return `INSUFFICIENT_EVIDENCE`.

## Synthesize Findings

Report:

- Incident scope
- Availability impact
- Earliest abnormal signal
- Supporting evidence
- Leading hypothesis
- Alternative hypotheses
- Confidence
- Missing evidence

## Recommended Remediation Steps

If only the failure domain is known, state the failure domain rather than inventing a lower-level root cause. Recommend additional metrics or observability sources needed to isolate the cause.
