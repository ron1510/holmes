---
name: database-investigation
description: Investigate database health, latency, availability, connection pressure, replication, and resource issues using only Prometheus metrics and Grafana dashboards, without direct access to the database.
---

# Database Investigation

## Goal

Determine whether a database is degraded, characterize the degradation, identify the strongest supported cause from observability data, and state what additional evidence is required when metrics are insufficient.

## Scope and Safety

- Never connect directly to the database.
- Never execute database queries, explain plans, administrative commands, or database APIs.
- Use only Prometheus metrics and Grafana dashboards.
- Treat database type, cluster, instance, and environment as explicit dimensions.
- Do not infer query-level root causes unless query-level metrics are actually exposed through observability.

## Workflow

1. **Identify the database**
   - Determine `db_type`, cluster, instance, environment, and incident time window.
   - If multiple instances are affected, compare them.

2. **Check availability**
   - Availability/health indicators
   - Error rate
   - Failed connections
   - Restart/failover indicators when available

3. **Check latency**
   - Overall operation/query latency
   - Read/write latency where available
   - Compare against a healthy baseline

4. **Check throughput**
   - Operations per second
   - Read/write volume
   - Request rate
   - Look for sudden traffic changes that may explain pressure

5. **Check connection pressure**
   - Current connections
   - Maximum/limit
   - Utilization percentage
   - Connection failures or waits

6. **Check compute resources**
   - CPU utilization
   - Memory utilization
   - Memory pressure or swapping indicators when exposed

7. **Check storage**
   - Disk latency
   - IOPS
   - Throughput
   - Queue depth or saturation
   - Free space/capacity when exposed

8. **Check replication/cluster health**
   - Replication lag
   - Replica health
   - Failover/leader changes
   - Cluster-level imbalance when exposed

9. **Correlate signals**
   - Determine which metric moved first.
   - Avoid treating CPU, memory, disk, or connection pressure as the cause merely because they are high.
   - Check whether the suspected cause explains the observed latency/errors across the same time window.

10. **Assess evidence sufficiency**
    - Apply evidence-and-confidence rules.
    - If metrics show database degradation but cannot determine why, return `INSUFFICIENT_EVIDENCE`.

## Minimum Evidence Categories

For a confident database-level RCA, try to obtain:

- Latency
- Error rate
- Throughput
- Connections
- CPU
- Memory
- Storage indicators
- Replication/cluster indicators when applicable

Missing categories do not automatically block investigation, but they must reduce confidence when they could distinguish between plausible causes.

## Synthesize Findings

Report:

- Database type / cluster / instance
- Incident window
- Degraded signals
- Healthy signals
- Earliest abnormal signal
- Leading hypothesis
- Alternative hypotheses
- Confidence
- Missing evidence

## Recommended Remediation Steps

Recommend only actions supported by the evidence. If the likely issue requires data not exposed in metrics—for example slow-query details, lock information, or execution plans—state that explicitly instead of inventing a database-level RCA.
