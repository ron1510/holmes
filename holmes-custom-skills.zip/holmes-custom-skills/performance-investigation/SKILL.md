---
name: performance-investigation
description: Investigate latency, slow response time, throughput degradation, or performance regressions using only Prometheus metrics and Grafana dashboards.
---

# Performance Investigation

## Goal

Explain a performance degradation using observable evidence, distinguish bottlenecks from downstream symptoms, and identify what additional data is needed when metrics cannot establish causality.

## Scope and Safety

- Use only Prometheus metrics and Grafana dashboards.
- Do not use direct service, database, cloud, host, or infrastructure APIs.
- Do not infer a bottleneck solely because a resource metric is high.
- Always compare the incident period to a relevant baseline.

## Workflow

1. **Define the performance symptom**
   - Identify the affected system.
   - Identify the metric representing user-visible or service-visible degradation.
   - Establish start time, duration, and current state.

2. **Analyze latency**
   - p50/p95/p99 where available
   - Operation-specific latency when available
   - Compare against baseline

3. **Analyze throughput**
   - Request/operation rate
   - Read/write volume
   - Determine whether load increased, decreased, or stayed stable

4. **Analyze errors**
   - Error rate
   - Timeouts
   - Retries when exposed
   - Determine whether errors preceded or followed latency

5. **Analyze resource pressure**
   - CPU
   - Memory
   - Disk latency/IOPS/queue
   - Connections
   - Queue depth
   - Other capacity indicators exposed by the dashboard

6. **Correlate dependencies represented in metrics**
   - Compare timestamps across related systems.
   - Identify whether upstream or downstream degradation began first.
   - Do not claim dependency causality unless timing and evidence support it.

7. **Differentiate cause from symptom**
   - Ask whether the suspected bottleneck changed before the user-visible degradation.
   - Ask whether the suspected bottleneck is specific to affected instances.
   - Check whether healthy instances provide a useful control group.

8. **Assess evidence sufficiency**
   - Apply evidence-and-confidence rules.
   - If multiple explanations remain plausible, return `INSUFFICIENT_EVIDENCE`.

## Synthesize Findings

Report:

- Performance symptom
- Baseline versus incident values
- Earliest abnormal signal
- Correlated signals
- Leading bottleneck hypothesis
- Alternative hypotheses
- Confidence
- Missing observability required to continue

## Recommended Remediation Steps

Do not recommend tuning, scaling, restarts, or configuration changes unless the supporting evidence is clear. When uncertain, recommend the next metric or dashboard signal required to validate the hypothesis.
