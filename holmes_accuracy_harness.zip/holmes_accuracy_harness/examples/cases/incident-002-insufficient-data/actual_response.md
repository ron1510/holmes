Checkout error rate increased during the 14:00-14:15 window.

The available data shows the symptom, but downstream dependency metrics are missing. Because those dependency metrics are missing, I cannot determine the root cause from the provided artifacts. There is not enough evidence to say whether this was caused by a database outage, network issue, or another service.
