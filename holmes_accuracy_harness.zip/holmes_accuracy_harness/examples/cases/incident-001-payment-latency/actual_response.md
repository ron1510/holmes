The likely root cause is database connection pool saturation.

Investigation order:
1. I started from the user-facing symptom: checkout p95 latency increased during the 10:00-10:30 window.
2. I checked service latency and error metrics. Checkout p95 latency rose sharply and the application error rate increased shortly afterward.
3. I inspected the database dashboard or metrics. Database active connections reached the configured limit at the same time.
4. I correlated timing between database saturation and checkout latency. The timing supports DB pool exhaustion as the cause.

There is enough data in the provided Prometheus metrics and Grafana dashboard snapshots to identify this as the likely root cause.
