# HolmesGPT Accuracy Harness

Small offline accuracy test harness for a standalone HolmesGPT agent.

It is intentionally file-based and dependency-free:

- Test cases live in directories.
- Each test has a `test.yaml`.
- Metrics and dashboards are loaded only from that test directory.
- Reports are written as JSON and Markdown.
- Scoring is deterministic by default, with room to add a local judge model later.

## Quick Start

Run the included sample:

```bash
python -m holmes_accuracy run --cases examples/cases --out reports
```

Run one case:

```bash
python -m holmes_accuracy run --case examples/cases/incident-001-payment-latency --out reports
```

Run against a real HolmesGPT command:

```bash
python -m holmes_accuracy run \
  --cases ./cases \
  --out ./reports \
  --agent-command "holmesgpt investigate --question-file {question_file} --evidence-dir {case_dir}"
```

The command should print the agent's final answer to stdout.

Available placeholders:

- `{case_dir}`
- `{question}`
- `{question_file}`
- `{test_id}`
- `{time_start}`
- `{time_end}`

## Test Case Layout

```text
cases/
  incident-001/
    test.yaml
    actual_response.md              # optional fallback when no agent command is supplied
    metrics/
      request_latency.csv
      db_connections.csv
    dashboards/
      checkout-overview.json
      checkout-overview.png
```

## Scoring

The default score is 100 points:

- 30 root cause finding
- 25 reasoning with data
- 20 correct data sufficiency judgment
- 15 no hallucinated metrics, dashboards, panels, events, or dependencies
- 10 correct order of investigation

The scorer is deliberately conservative. It rewards explicit, evidence-backed answers and penalizes unsupported claims.

## Minimal `test.yaml`

```yaml
id: incident-001-payment-latency
title: Checkout latency caused by database saturation

question: >
  Investigate why checkout latency increased between 10:00 and 10:30.

time_window:
  start: "2026-08-12T10:00:00Z"
  end: "2026-08-12T10:30:00Z"

expected:
  root_cause:
    summary: Database connection pool saturation caused checkout latency.
    accepted_aliases:
      - DB pool exhaustion
      - database saturation
      - connection limit reached

  required_evidence:
    - checkout p95 latency increased
    - database active connections reached the limit
    - application error rate increased

  insufficient_data:
    expected: false

  forbidden_claims:
    - Kubernetes node failure
    - Kafka outage
    - deployment rollback

  expected_investigation_order:
    - user-facing symptom
    - service latency and error metrics
    - database dashboard or metrics
    - correlate timing
```

## Practical Advice

Start with 10-20 high-quality incidents. Tune aliases and required evidence after reviewing the first reports. The tests become much more valuable when the expected answers are reviewed by the same people who investigate production incidents.
