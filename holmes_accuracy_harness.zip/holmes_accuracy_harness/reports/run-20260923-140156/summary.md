# HolmesGPT Accuracy Report

Run: `run-20260923-140156`
Tests: 2
Average score: 100.0

| Test | Score | Summary |
|---|---:|---|
| `incident-001-payment-latency` | 100 | Full score (100/100). The answer matched the expected finding and evidence. |
| `incident-002-insufficient-data` | 100 | Full score (100/100). The answer matched the expected finding and evidence. |
