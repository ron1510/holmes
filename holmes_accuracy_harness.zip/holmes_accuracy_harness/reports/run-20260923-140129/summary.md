# HolmesGPT Accuracy Report

Run: `run-20260923-140129`
Tests: 2
Average score: 98.5

| Test | Score | Summary |
|---|---:|---|
| `incident-001-payment-latency` | 100 | Full score (100/100). The answer matched the expected finding and evidence. |
| `incident-002-insufficient-data` | 97 | Score 97/100. Deductions were applied for: investigation order. |
