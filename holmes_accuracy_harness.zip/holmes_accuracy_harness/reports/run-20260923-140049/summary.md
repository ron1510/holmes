# HolmesGPT Accuracy Report

Run: `run-20260923-140049`
Tests: 2
Average score: 94.5

| Test | Score | Summary |
|---|---:|---|
| `incident-001-payment-latency` | 97 | Score 97/100. Deductions were applied for: investigation order. |
| `incident-002-insufficient-data` | 92 | Score 92/100. Deductions were applied for: no hallucination, investigation order. |
