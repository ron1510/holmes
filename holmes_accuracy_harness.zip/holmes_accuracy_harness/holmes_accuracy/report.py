from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class ReportResult:
    run_dir: Path
    summary_json: Path
    summary_markdown: Path
    average_score: float


def write_reports(out_dir: Path, results: list[dict]) -> ReportResult:
    run_id = datetime.now(timezone.utc).strftime("run-%Y%m%d-%H%M%S")
    run_dir = out_dir / run_id
    per_test_dir = run_dir / "per-test"
    per_test_dir.mkdir(parents=True, exist_ok=True)

    for result in results:
        test_id = result["test_id"]
        (per_test_dir / f"{test_id}.json").write_text(
            json.dumps(result, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        (per_test_dir / f"{test_id}.md").write_text(_per_test_markdown(result), encoding="utf-8")

    average = sum(item["score"] for item in results) / len(results) if results else 0.0
    summary = {
        "run_id": run_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "average_score": average,
        "test_count": len(results),
        "results": [
            {
                "test_id": item["test_id"],
                "title": item.get("title", ""),
                "score": item["score"],
                "summary": item["summary"],
            }
            for item in results
        ],
    }
    summary_json = run_dir / "summary.json"
    summary_md = run_dir / "summary.md"
    summary_json.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    summary_md.write_text(_summary_markdown(summary, results), encoding="utf-8")

    return ReportResult(run_dir, summary_json, summary_md, average)


def _summary_markdown(summary: dict, results: list[dict]) -> str:
    lines = [
        "# HolmesGPT Accuracy Report",
        "",
        f"Run: `{summary['run_id']}`",
        f"Tests: {summary['test_count']}",
        f"Average score: {summary['average_score']:.1f}",
        "",
        "| Test | Score | Summary |",
        "|---|---:|---|",
    ]
    for item in results:
        lines.append(f"| `{item['test_id']}` | {item['score']} | {_escape_table(item['summary'])} |")
    lines.append("")
    return "\n".join(lines)


def _per_test_markdown(result: dict) -> str:
    lines = [
        f"# {result.get('title') or result['test_id']}",
        "",
        f"Score: **{result['score']}**",
        "",
        "## Category Scores",
        "",
        "| Category | Score | Max |",
        "|---|---:|---:|",
    ]
    for name, item in result["category_scores"].items():
        lines.append(f"| {name.replace('_', ' ')} | {item['score']} | {item['max']} |")
    lines.extend(["", "## Summary", "", result["summary"], "", "## Notes", ""])
    for note in result.get("notes", []):
        lines.append(f"- {note}")
    lines.extend(["", "## Final Answer", "", "```text", result.get("final_answer", ""), "```", ""])
    return "\n".join(lines)


def _escape_table(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")
