"""Offline HolmesGPT accuracy harness."""

__version__ = "0.1.0"
