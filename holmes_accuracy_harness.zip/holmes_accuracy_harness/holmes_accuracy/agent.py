from __future__ import annotations

import json
import os
import shlex
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class AgentRun:
    final_answer: str
    command: str | None = None
    return_code: int | None = None
    stderr: str = ""
    tool_log: list[dict] = field(default_factory=list)


def run_agent(case: dict, case_dir: Path, agent_command: str | None, timeout_seconds: int) -> AgentRun:
    if agent_command:
        return _run_command(case, case_dir, agent_command, timeout_seconds)

    response_file = case_dir / "actual_response.md"
    if response_file.exists():
        return AgentRun(final_answer=response_file.read_text(encoding="utf-8"))

    raise RuntimeError(
        f"No agent command was supplied and {response_file} does not exist. "
        "Provide --agent-command or save a prior response as actual_response.md."
    )


def _run_command(case: dict, case_dir: Path, command_template: str, timeout_seconds: int) -> AgentRun:
    question = str(case.get("question", ""))
    test_id = str(case.get("id", case_dir.name))
    time_window = case.get("time_window") or {}

    with tempfile.TemporaryDirectory(prefix="holmes-accuracy-") as tmp:
        question_file = Path(tmp) / "question.txt"
        question_file.write_text(question, encoding="utf-8")

        values = {
            "case_dir": str(case_dir),
            "question": question,
            "question_file": str(question_file),
            "test_id": test_id,
            "time_start": str(time_window.get("start", "")),
            "time_end": str(time_window.get("end", "")),
        }
        command = command_template.format(**values)

        env = os.environ.copy()
        env.update(
            {
                "HOLMES_ACCURACY_CASE_DIR": str(case_dir),
                "HOLMES_ACCURACY_TEST_ID": test_id,
                "HOLMES_ACCURACY_QUESTION_FILE": str(question_file),
            }
        )

        completed = subprocess.run(
            shlex.split(command),
            cwd=str(case_dir),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )

    tool_log = _load_tool_log(case_dir)
    return AgentRun(
        final_answer=completed.stdout.strip(),
        command=command,
        return_code=completed.returncode,
        stderr=completed.stderr.strip(),
        tool_log=tool_log,
    )


def _load_tool_log(case_dir: Path) -> list[dict]:
    for name in ("tool_log.json", "agent_tool_log.json"):
        path = case_dir / name
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
            if isinstance(data, dict) and isinstance(data.get("events"), list):
                return data["events"]
    return []
