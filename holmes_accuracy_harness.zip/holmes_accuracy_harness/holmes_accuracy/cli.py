from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .runner import run_suite


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="holmes-accuracy")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run one case or a directory of cases.")
    target = run_parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--cases", type=Path, help="Directory containing test case directories.")
    target.add_argument("--case", type=Path, help="Single test case directory.")
    run_parser.add_argument("--out", type=Path, default=Path("reports"), help="Output reports directory.")
    run_parser.add_argument("--agent-command", help="External HolmesGPT command template.")
    run_parser.add_argument("--timeout-seconds", type=int, default=300)
    run_parser.add_argument("--fail-under", type=int, default=None, help="Exit non-zero if average score is lower.")

    args = parser.parse_args(argv)

    if args.command == "run":
        result = run_suite(
            cases_dir=args.cases,
            case_dir=args.case,
            out_dir=args.out,
            agent_command=args.agent_command,
            timeout_seconds=args.timeout_seconds,
        )
        print(f"Wrote report: {result.summary_markdown}")
        print(f"Average score: {result.average_score:.1f}")
        if args.fail_under is not None and result.average_score < args.fail_under:
            sys.exit(2)
