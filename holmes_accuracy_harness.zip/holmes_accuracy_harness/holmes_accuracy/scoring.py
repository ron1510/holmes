from __future__ import annotations

import re
from pathlib import Path

from .agent import AgentRun
from .artifacts import EvidenceInventory


WEIGHTS = {
    "root_cause": 30,
    "reasoning_with_data": 25,
    "data_sufficiency": 20,
    "no_hallucination": 15,
    "investigation_order": 10,
}


def score_case(case: dict, case_dir: Path, inventory: EvidenceInventory, agent_run: AgentRun) -> dict:
    answer = agent_run.final_answer or ""
    expected = case.get("expected") or {}

    categories = {
        "root_cause": _score_root_cause(answer, expected),
        "reasoning_with_data": _score_reasoning(answer, expected),
        "data_sufficiency": _score_data_sufficiency(answer, expected),
        "no_hallucination": _score_hallucination(answer, expected, inventory),
        "investigation_order": _score_investigation_order(answer, expected, agent_run.tool_log),
    }

    score = sum(item["score"] for item in categories.values())
    notes = []
    for item in categories.values():
        notes.extend(item.get("notes", []))

    return {
        "test_id": str(case.get("id", case_dir.name)),
        "title": str(case.get("title", "")),
        "score": score,
        "category_scores": categories,
        "summary": _summary(categories, score),
        "notes": notes,
        "final_answer": answer,
        "agent": {
            "command": agent_run.command,
            "return_code": agent_run.return_code,
            "stderr": agent_run.stderr,
        },
        "inventory": {
            "metric_files": inventory.metric_files,
            "dashboard_files": inventory.dashboard_files,
            "metric_names": sorted(inventory.metric_names),
            "dashboard_names": sorted(inventory.dashboard_names),
            "panel_names": sorted(inventory.panel_names),
        },
    }


def _score_root_cause(answer: str, expected: dict) -> dict:
    max_score = WEIGHTS["root_cause"]
    root = expected.get("root_cause") or {}
    candidates = [root.get("summary", "")]
    candidates.extend(root.get("accepted_aliases") or [])
    candidates = [item for item in candidates if item]

    if not candidates:
        return _category(max_score, max_score, ["No expected root cause configured; giving full credit."])

    matched = [candidate for candidate in candidates if _contains_concept(answer, candidate)]
    if matched:
        return _category(max_score, max_score, [f"Matched root cause: {matched[0]}"])

    return _category(0, max_score, ["Expected root cause was not found in the answer."])


def _score_reasoning(answer: str, expected: dict) -> dict:
    max_score = WEIGHTS["reasoning_with_data"]
    evidence = expected.get("required_evidence") or []
    if not evidence:
        return _category(max_score, max_score, ["No required evidence configured; giving full credit."])

    matched = [item for item in evidence if _contains_concept(answer, str(item))]
    score = round(max_score * len(matched) / len(evidence))
    return _category(score, max_score, [f"Matched {len(matched)}/{len(evidence)} required evidence items."])


def _score_data_sufficiency(answer: str, expected: dict) -> dict:
    max_score = WEIGHTS["data_sufficiency"]
    config = expected.get("insufficient_data") or {}
    expected_insufficient = bool(config.get("expected", False))
    says_insufficient = _says_insufficient(answer)

    if expected_insufficient == says_insufficient:
        return _category(max_score, max_score, ["Data sufficiency judgment matched expectation."])

    if expected_insufficient:
        return _category(0, max_score, ["Expected an insufficient-data response, but the answer gave a finding."])
    return _category(0, max_score, ["Expected a finding with enough data, but the answer claimed insufficient data."])


def _score_hallucination(answer: str, expected: dict, inventory: EvidenceInventory) -> dict:
    max_score = WEIGHTS["no_hallucination"]
    forbidden = [str(item) for item in expected.get("forbidden_claims") or []]
    hits = [item for item in forbidden if _contains_concept(answer, item) and not _mentioned_as_uncertain(answer, item)]

    unsupported_metrics = _unsupported_backtick_claims(answer, inventory.metric_names)
    unsupported_dashboards = _unsupported_quoted_claims(answer, inventory.dashboard_names | inventory.panel_names)

    penalties = len(hits) * 5 + len(unsupported_metrics) * 3 + len(unsupported_dashboards) * 2
    score = max(0, max_score - penalties)

    notes = []
    if hits:
        notes.append(f"Forbidden claims found: {', '.join(hits)}")
    if unsupported_metrics:
        notes.append(f"Possible unsupported metric references: {', '.join(unsupported_metrics)}")
    if unsupported_dashboards:
        notes.append(f"Possible unsupported dashboard/panel references: {', '.join(unsupported_dashboards)}")
    if not notes:
        notes.append("No configured forbidden or unsupported claims detected.")

    return _category(score, max_score, notes)


def _score_investigation_order(answer: str, expected: dict, tool_log: list[dict]) -> dict:
    max_score = WEIGHTS["investigation_order"]
    expected_steps = [str(item) for item in expected.get("expected_investigation_order") or []]
    if not expected_steps:
        return _category(max_score, max_score, ["No expected investigation order configured; giving full credit."])

    observed = _observed_sequence(answer, tool_log)
    positions = []
    for step in expected_steps:
        positions.append(_first_concept_position(observed, step))

    matched = [pos for pos in positions if pos >= 0]
    if not matched:
        return _category(0, max_score, ["No expected investigation steps were found."])
    if len(matched) == len(expected_steps) and _is_non_decreasing(matched):
        return _category(max_score, max_score, [f"Matched {len(matched)}/{len(expected_steps)} investigation steps in order."])

    ordered_pairs = 0
    possible_pairs = 0
    for i in range(len(positions)):
        for j in range(i + 1, len(positions)):
            if positions[i] >= 0 and positions[j] >= 0:
                possible_pairs += 1
                if positions[i] <= positions[j]:
                    ordered_pairs += 1

    coverage = len(matched) / len(expected_steps)
    order_quality = ordered_pairs / possible_pairs if possible_pairs else 1.0
    score = round(max_score * coverage * order_quality)
    return _category(score, max_score, [f"Matched {len(matched)}/{len(expected_steps)} investigation steps in rough order."])


def _category(score: int, max_score: int, notes: list[str]) -> dict:
    return {"score": int(score), "max": max_score, "notes": notes}


def _summary(categories: dict, total: int) -> str:
    weak = [name.replace("_", " ") for name, item in categories.items() if item["score"] < item["max"]]
    if not weak:
        return f"Full score ({total}/100). The answer matched the expected finding and evidence."
    return f"Score {total}/100. Deductions were applied for: {', '.join(weak)}."


def _contains_concept(text: str, concept: str) -> bool:
    text_tokens = _tokens(text)
    concept_tokens = _tokens(concept)
    if not concept_tokens:
        return False
    if " ".join(concept_tokens) in " ".join(text_tokens):
        return True
    overlap = len(set(text_tokens) & set(concept_tokens))
    return overlap / len(set(concept_tokens)) >= 0.65


def _mentioned_as_uncertain(text: str, concept: str) -> bool:
    concept_tokens = _tokens(concept)
    if not concept_tokens:
        return False
    sentences = re.split(r"(?<=[.!?])\s+", text)
    uncertainty_markers = (
        "cannot determine",
        "can't determine",
        "not enough",
        "insufficient",
        "missing",
        "whether",
        "no evidence",
        "not caused by",
    )
    for sentence in sentences:
        if _contains_concept(sentence, concept) and any(marker in sentence.lower() for marker in uncertainty_markers):
            return True
    return False


def _tokens(value: str) -> list[str]:
    return re.findall(r"[a-z0-9_:/.-]+", value.lower())


def _says_insufficient(answer: str) -> bool:
    patterns = [
        "not enough data",
        "insufficient data",
        "cannot determine",
        "can't determine",
        "cannot conclude",
        "need more data",
        "not enough evidence",
    ]
    text = answer.lower()
    return any(pattern in text for pattern in patterns)


def _unsupported_backtick_claims(answer: str, allowed: set[str]) -> list[str]:
    claims = re.findall(r"`([^`]+)`", answer)
    unsupported = []
    for claim in claims:
        normalized = claim.strip().lower()
        if _looks_like_metric(normalized) and not _allowed_claim(normalized, allowed):
            unsupported.append(claim)
    return sorted(set(unsupported))


def _unsupported_quoted_claims(answer: str, allowed: set[str]) -> list[str]:
    claims = re.findall(r'"([^"]+)"', answer)
    unsupported = []
    keywords = ("dashboard", "panel", "overview", "latency", "errors", "cpu", "memory")
    for claim in claims:
        normalized = claim.strip().lower()
        if any(keyword in normalized for keyword in keywords) and not _allowed_claim(normalized, allowed):
            unsupported.append(claim)
    return sorted(set(unsupported))


def _allowed_claim(claim: str, allowed: set[str]) -> bool:
    if not allowed:
        return True
    return any(claim == item or claim in item or item in claim for item in allowed)


def _looks_like_metric(value: str) -> bool:
    return "_" in value or ":" in value or "{" in value


def _observed_sequence(answer: str, tool_log: list[dict]) -> str:
    parts = []
    for event in tool_log:
        parts.extend(str(value) for value in event.values() if isinstance(value, (str, int, float)))
    parts.append(answer)
    return "\n".join(parts)


def _first_concept_position(text: str, concept: str) -> int:
    text_lower = text.lower()
    tokens = [token for token in _tokens(concept) if len(token) >= 4]
    phrase_pos = text_lower.find(concept.lower())
    if phrase_pos >= 0:
        return phrase_pos
    positions = [text_lower.find(token) for token in tokens]
    positions = [pos for pos in positions if pos >= 0]
    if not positions:
        return -1
    # Use the median token position so one generic word such as "metrics" does not
    # make a later investigation step appear too early.
    positions = sorted(positions)
    return positions[len(positions) // 2]


def _is_non_decreasing(values: list[int]) -> bool:
    return all(values[index] <= values[index + 1] for index in range(len(values) - 1))
