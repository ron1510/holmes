from __future__ import annotations

import ast
from pathlib import Path


def load_yaml_file(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(path)
    return loads(path.read_text(encoding="utf-8"))


def loads(text: str) -> dict:
    lines = _preprocess(text)
    if not lines:
        return {}
    root: dict = {}
    stack: list[tuple[int, object]] = [(-1, root)]
    index = 0
    while index < len(lines):
        indent, content = lines[index]
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]

        if content.startswith("- "):
            if not isinstance(parent, list):
                raise ValueError(f"List item has non-list parent near: {content}")
            item_content = content[2:].strip()
            if not item_content:
                item: object = {}
                parent.append(item)
                stack.append((indent, item))
            elif ":" in item_content and not item_content.startswith(("'", '"')):
                key, value = _split_key_value(item_content)
                item = {key: _parse_scalar(value)}
                parent.append(item)
                if value == "":
                    stack.append((indent, item[key]))
            else:
                parent.append(_parse_scalar(item_content))
            index += 1
            continue

        key, value = _split_key_value(content)
        if value in {">", "|"}:
            block, index = _read_block(lines, index + 1, indent)
            parsed_value = block if value == "|" else " ".join(line.strip() for line in block.splitlines())
        elif value == "":
            parsed_value = _empty_container(lines, index, indent)
            index += 1
        else:
            parsed_value = _parse_scalar(value)
            index += 1

        if isinstance(parent, dict):
            parent[key] = parsed_value
        else:
            raise ValueError(f"Mapping entry has non-dict parent near: {content}")

        if isinstance(parsed_value, (dict, list)):
            stack.append((indent, parsed_value))

    return root


def _preprocess(text: str) -> list[tuple[int, str]]:
    result = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        result.append((indent, raw.strip()))
    return result


def _split_key_value(content: str) -> tuple[str, str]:
    if ":" not in content:
        raise ValueError(f"Expected key: value entry near: {content}")
    key, value = content.split(":", 1)
    return key.strip(), value.strip()


def _empty_container(lines: list[tuple[int, str]], index: int, indent: int) -> dict | list:
    for next_indent, next_content in lines[index + 1 :]:
        if next_indent <= indent:
            break
        return [] if next_content.startswith("- ") else {}
    return {}


def _read_block(lines: list[tuple[int, str]], index: int, parent_indent: int) -> tuple[str, int]:
    block_lines = []
    while index < len(lines):
        indent, content = lines[index]
        if indent <= parent_indent:
            break
        block_lines.append(content)
        index += 1
    return "\n".join(block_lines), index


def _parse_scalar(value: str):
    if value == "":
        return {}
    lowered = value.lower()
    if lowered in {"true", "false"}:
        return lowered == "true"
    if lowered in {"null", "none", "~"}:
        return None
    if value.startswith("[") or value.startswith("{"):
        try:
            return ast.literal_eval(value)
        except (SyntaxError, ValueError):
            return value
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        return value
