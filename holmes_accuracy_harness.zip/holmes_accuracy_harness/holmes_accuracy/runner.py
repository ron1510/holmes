from __future__ import annotations

from pathlib import Path

from .agent import run_agent
from .artifacts import inventory_case
from .report import ReportResult, write_reports
from .scoring import score_case
from .simple_yaml import load_yaml_file


def run_suite(
    cases_dir: Path | None,
    case_dir: Path | None,
    out_dir: Path,
    agent_command: str | None,
    timeout_seconds: int,
) -> ReportResult:
    case_dirs = _discover_cases(cases_dir, case_dir)
    results: list[dict] = []

    for directory in case_dirs:
        case = load_yaml_file(directory / "test.yaml")
        inventory = inventory_case(directory)
        agent_run = run_agent(case, directory, agent_command, timeout_seconds)
        result = score_case(case, directory, inventory, agent_run)
        results.append(result)

    return write_reports(out_dir, results)


def _discover_cases(cases_dir: Path | None, case_dir: Path | None) -> list[Path]:
    if case_dir is not None:
        _validate_case_dir(case_dir)
        return [case_dir]

    assert cases_dir is not None
    if not cases_dir.exists():
        raise FileNotFoundError(f"Cases directory does not exist: {cases_dir}")

    case_dirs = sorted(path for path in cases_dir.iterdir() if path.is_dir() and (path / "test.yaml").exists())
    if not case_dirs:
        raise RuntimeError(f"No test cases found under {cases_dir}")
    return case_dirs


def _validate_case_dir(case_dir: Path) -> None:
    if not case_dir.exists():
        raise FileNotFoundError(f"Case directory does not exist: {case_dir}")
    if not (case_dir / "test.yaml").exists():
        raise FileNotFoundError(f"Missing test.yaml in {case_dir}")
