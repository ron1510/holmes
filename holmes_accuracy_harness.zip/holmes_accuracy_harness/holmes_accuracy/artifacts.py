from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class EvidenceInventory:
    metric_files: list[str] = field(default_factory=list)
    dashboard_files: list[str] = field(default_factory=list)
    metric_names: set[str] = field(default_factory=set)
    dashboard_names: set[str] = field(default_factory=set)
    panel_names: set[str] = field(default_factory=set)


def inventory_case(case_dir: Path) -> EvidenceInventory:
    inventory = EvidenceInventory()

    metrics_dir = case_dir / "metrics"
    if metrics_dir.exists():
        for path in sorted(p for p in metrics_dir.rglob("*") if p.is_file()):
            rel = path.relative_to(case_dir).as_posix()
            inventory.metric_files.append(rel)
            inventory.metric_names.update(_metric_names_from_file(path))

    dashboards_dir = case_dir / "dashboards"
    if dashboards_dir.exists():
        for path in sorted(p for p in dashboards_dir.rglob("*") if p.is_file()):
            rel = path.relative_to(case_dir).as_posix()
            inventory.dashboard_files.append(rel)
            inventory.dashboard_names.add(path.stem.lower())
            if path.suffix.lower() == ".json":
                inventory.panel_names.update(_panel_names_from_grafana_json(path))

    return inventory


def _metric_names_from_file(path: Path) -> set[str]:
    names: set[str] = {path.stem.lower()}
    suffix = path.suffix.lower()
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return names

    if suffix == ".csv":
        first = text.splitlines()[0] if text.splitlines() else ""
        for col in first.split(","):
            col = col.strip().strip('"').lower()
            if col and col not in {"time", "timestamp", "value"}:
                names.add(col)
    elif suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return names
        _walk_metric_json(data, names)

    return names


def _walk_metric_json(value, names: set[str]) -> None:
    if isinstance(value, dict):
        metric = value.get("metric")
        if isinstance(metric, dict):
            name = metric.get("__name__")
            if isinstance(name, str):
                names.add(name.lower())
        for key in ("query", "expr", "metric_name", "name"):
            item = value.get(key)
            if isinstance(item, str) and _looks_metric_like(item):
                names.add(item.lower())
        for child in value.values():
            _walk_metric_json(child, names)
    elif isinstance(value, list):
        for child in value:
            _walk_metric_json(child, names)


def _panel_names_from_grafana_json(path: Path) -> set[str]:
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except json.JSONDecodeError:
        return set()

    names: set[str] = set()
    title = data.get("title")
    if isinstance(title, str):
        names.add(title.lower())
    _walk_panels(data, names)
    return names


def _walk_panels(value, names: set[str]) -> None:
    if isinstance(value, dict):
        title = value.get("title")
        if isinstance(title, str):
            names.add(title.lower())
        for child in value.values():
            _walk_panels(child, names)
    elif isinstance(value, list):
        for child in value:
            _walk_panels(child, names)


def _looks_metric_like(value: str) -> bool:
    return any(ch in value for ch in ("_", ":", "{", "[")) and len(value) <= 160
